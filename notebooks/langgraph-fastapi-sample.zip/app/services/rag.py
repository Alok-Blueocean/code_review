# RAG pipeline logic
